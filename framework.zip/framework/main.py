from config import config
#from config import instance
from services.enviroment import SystemInfo
from services.ec2 import EC2Manager

import log
import util
from log import Log

logger = Log("Adaptative Framework log")

logger.debug("Starting the framework...")
logger.info("Getting system information...")
system_info = SystemInfo().get_system_info()

#system_info = SystemInfo()
for key, value in system_info.items():
    print(key + ':', value)

logger.info("System information collected.")
logger.info("Creating AWS instance...")
ec2Manager = EC2Manager()

logger.info("Listing AWS instances...")
instances = ec2Manager.list_instances()
print("instances")
print(instances)
print("\n\n")
print("instance[0]: ")
print(instances[0])

print(instances[0]['InstanceId'])

logger.info("Creating AWS instance...")
#instance = ec2Manager.create_instance("ami-01afb69abc2756b9e", "g4dn.xlarge",1, "walisson-key", ["walisson-group"])

#print(instance)

#instance_id=instance['InstanceId']

inf = ec2Manager.get_instance_information('i-010692b6ee0e47d9d')
print(inf)

print("\n\nstate: \n")
print(inf)

#logger.info(instace)
logger.info("Instance created...")



#logger.info("Conectando ao banco de dados")
#logger.warning("Falha ao conectar ao banco de dados")
#logger.error("Tentativa de login inválida")
#logger.critical("Erro crítico no sistema")

#acessar instância
#dados = util.openJason("config/");
#print(dados);
#print("tesstando o a framework")
