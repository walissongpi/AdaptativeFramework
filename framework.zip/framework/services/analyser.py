import platform
import psutil
import GPUtil

def get_system_info():
    system_info = {}

    system_info['Sistema Operacional'] = platform.platform()

    system_info['Processador'] = platform.processor()
    system_info['Arquitetura'] = platform.architecture()[0]
    system_info['Frequência'] = psutil.cpu_freq().current
    system_info['Núcleos Físicos'] = psutil.cpu_count(logical=False)
    system_info['Núcleos Lógicos'] = psutil.cpu_count(logical=True)


    memory_info = psutil.virtual_memory()
    system_info['Memória Total'] = memory_info.total
    system_info['Memória Disponível'] = memory_info.available


    disk_info = psutil.disk_usage('/')
    system_info['Armazenamento Total'] = disk_info.total
    system_info['Armazenamento Disponível'] = disk_info.free


    try:
        gpus = GPUtil.getGPUs()
        gpu_info = []
        for gpu in gpus:
            gpu_info.append({
                'Nome': gpu.name,
                'VRAM Total': gpu.memoryTotal,
                'VRAM Usada': gpu.memoryUsed,
                'VRAM Livre': gpu.memoryFree,
                'Porcentagem de Uso': gpu.load * 100
            })
        system_info['Placas de Vídeo'] = gpu_info
    except Exception as e:
        system_info['Placas de Vídeo'] = "Erro ao obter informações da placa de vídeo: " + str(e)

    return system_info

# Obtendo e imprimindo as informações do sistema
system_info = get_system_info()
for key, value in system_info.items():
    print(key + ':', value)
