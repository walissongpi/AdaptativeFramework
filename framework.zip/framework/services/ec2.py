import boto3

class EC2Manager:
    def __init__(self, region_name='us-east-1'):
        self.ec2 = boto3.client('ec2', region_name=region_name)

    def list_instances(self):
        response = self.ec2.describe_instances()
        instances = []
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                instances.append({
                    'InstanceId': instance['InstanceId'],
                    'InstanceType': instance['InstanceType'],
                    'State': instance['State']['Name']
                })
        return instances

    def get_instance_information(self, instance_id):
        response = self.ec2.describe_instances(InstanceIds=[instance_id])
        return response

    def start_instance(self, instance_id):
        self.ec2.start_instances(InstanceIds=[instance_id])
        print(f"Instance {instance_id} started.")

    def stop_instance(self, instance_id):
        self.ec2.stop_instances(InstanceIds=[instance_id])
        print(f"Instance {instance_id} stopped.")

    def terminate_instance(self, instance_id):
        self.ec2.terminate_instances(InstanceIds=[instance_id])
        print(f"Instance {instance_id} terminated.")

    def create_instance(self, image_id, instance_type, count=1, key_name=None, security_groups=None):
        """
        Cria uma nova instância EC2.

        Args:
            image_id (str): ID da AMI a ser usada.
            instance_type (str): Tipo da instância (ex: t2.micro).
            count (int, optional): Número de instâncias a serem criadas. Defaults to 1.
            key_name (str, optional): Nome do par de chaves a ser usado. Defaults to None.
            security_groups (list, optional): Lista de IDs de grupos de segurança. Defaults to None.

        Returns:
            Dicionário com informações da instância.
        """
        if security_groups is None:
            security_groups = []



        tags = [{
            'ResourceType': 'instance',
            'Tags': [{
                'Key': 'Nome',
                'Value': 'AdaptativeFramework'
            }]
        }]


        return self.ec2.run_instances(
            ImageId=image_id,
            InstanceType=instance_type,
            MinCount=count,
            MaxCount=count,
            KeyName=key_name,
            SecurityGroups=security_groups,
            TagSpecifications=tags,
        )["Instances"][0]
