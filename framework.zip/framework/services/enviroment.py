import platform
import psutil
import GPUtil

class SystemInfo:
    def __init__(self):
        self.system_info = {}

    def get_os_info(self):
        self.system_info['Sistema Operacional'] = platform.platform()

    def get_cpu_info(self):
        self.system_info['Processador'] = platform.processor()
        self.system_info['Arquitetura'] = platform.architecture()[0]
        self.system_info['Frequência'] = psutil.cpu_freq().current
        self.system_info['Núcleos Físicos'] = psutil.cpu_count(logical=False)
        self.system_info['Núcleos Lógicos'] = psutil.cpu_count(logical=True)

    def get_memory_info(self):
        memory_info = psutil.virtual_memory()
        self.system_info['Memória Total'] = memory_info.total
        self.system_info['Memória Disponível'] = memory_info.available

    def get_disk_info(self):
        disk_info = psutil.disk_usage('/')
        self.system_info['Armazenamento Total'] = disk_info.total
        self.system_info['Armazenamento Disponível'] = disk_info.free

    def get_gpu_info(self):
        try:
            gpus = GPUtil.getGPUs()
            gpu_info = []
            for gpu in gpus:
                gpu_info.append({
                    'Nome': gpu.name,
                    'VRAM Total': gpu.memoryTotal,
                    'VRAM Usada': gpu.memoryUsed,
                    'VRAM Livre': gpu.memoryFree,
                    'Porcentagem de Uso': gpu.load * 100
                })
            self.system_info['Placas de Vídeo'] = gpu_info
        except Exception as e:
            self.system_info['Placas de Vídeo'] = "Erro ao obter informações da placa de vídeo: " + str(e)

    def get_system_info(self):
        self.get_os_info()
        self.get_cpu_info()
        self.get_memory_info()
        self.get_disk_info()
        self.get_gpu_info()
        return self.system_info
