import logging

class Log:

    def __init__(self, name):
        """
        Construtor da classe.

        Args:
            name (str): Nome do logger.
        """
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)

        # Criar handlers para console e arquivo
        console_handler = logging.StreamHandler()
        file_handler = logging.FileHandler("framework.log")

        # Formatador de logs
        formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        console_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)

        # Adicionar handlers ao logger
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

    def debug(self, message):
        """
        Registra uma mensagem de log no nível DEBUG.

        Args:
            message (str): Mensagem a ser registrada.
        """
        self.logger.debug(message)

    def info(self, message):
        """
        Registra uma mensagem de log no nível INFO.

        Args:
            message (str): Mensagem a ser registrada.
        """
        self.logger.info(message)

    def warning(self, message):
        """
        Registra uma mensagem de log no nível WARNING.

        Args:
            message (str): Mensagem a ser registrada.
        """
        self.logger.warning(message)

    def error(self, message):
        """
        Registra uma mensagem de log no nível ERROR.

        Args:
            message (str): Mensagem a ser registrada.
        """
        self.logger.error(message)

    def critical(self, message):
        """
        Registra uma mensagem de log no nível CRITICAL.

        Args:
            message (str): Mensagem a ser registrada.
        """
        self.logger.critical(message)
